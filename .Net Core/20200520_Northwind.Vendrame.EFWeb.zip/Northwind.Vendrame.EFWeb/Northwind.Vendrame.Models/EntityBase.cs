﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Northwind.Vendrame.Models
{
    public abstract class EntityBase<T>
    {

    }

    public abstract class EntityBase : EntityBase<int>
    {

    }
}
