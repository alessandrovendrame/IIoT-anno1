﻿using Northwind.Vendrame.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace Northwind.Vendrame.Data
{
    public interface ICategoriesRepository : IRepository<Category, int>
    { 

    }
}
