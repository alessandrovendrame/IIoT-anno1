﻿using System;
using System.Collections.Generic;
using System.Text;
using Vendrame.Esame.Finale.Models;

namespace Vendrame.Esame.Finale.Data
{
    public interface IBigliettoData : IRepository<Biglietto, int>
    {
    }
}
