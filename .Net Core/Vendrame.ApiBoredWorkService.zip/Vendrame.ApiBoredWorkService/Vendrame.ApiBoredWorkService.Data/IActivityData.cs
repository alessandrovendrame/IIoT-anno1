﻿using System;
using System.Collections.Generic;
using System.Text;
using Vendrame.ApiBoredWorkService.Model;

namespace Vendrame.ApiBoredWorkService.Data
{
    public interface IActivityData : IRepository<Activity,int>
    {
    }
}
