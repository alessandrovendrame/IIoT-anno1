﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace Vendrame.ApiBoredWorkService.VendrameWorker
{
    class ActivityModel
    {
       
        public string ActivityType { get; set; }

      
        public string Type { get; set; }

        
        

    }
}
