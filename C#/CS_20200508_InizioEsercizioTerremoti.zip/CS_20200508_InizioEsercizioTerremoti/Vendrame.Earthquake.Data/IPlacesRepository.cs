﻿using System;
using System.Collections.Generic;
using System.Text;
using Vendrame.Earthquake.Models;

namespace Vendrame.Earthquake.Data
{
    public interface IPlacesRepository : IRepository<Place,int>
    {

    }
}
