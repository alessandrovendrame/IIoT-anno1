﻿using System;
using System.Collections.Generic;
using System.Text;
using Vendrame.Earthquake.Models;

namespace Vendrame.Earthquake.Data
{
    public class EarthquakesRepository : IEarthquakesRepository
    {
        public int Count()
        {
            throw new NotImplementedException();
        }

        public void Delete(int id)
        {
            throw new NotImplementedException();
        }

        public EarthquakeC Get(int id)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<EarthquakeC> GetAll()
        {
            throw new NotImplementedException();
        }

        public void Insert(EarthquakeC entity)
        {
            throw new NotImplementedException();
        }

        public void Update(EarthquakeC entity)
        {
            throw new NotImplementedException();
        }
    }
}
