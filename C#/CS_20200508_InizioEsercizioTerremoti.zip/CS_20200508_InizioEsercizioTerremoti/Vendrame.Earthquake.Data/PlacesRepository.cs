﻿using System;
using System.Collections.Generic;
using System.Text;
using Vendrame.Earthquake.Models;

namespace Vendrame.Earthquake.Data
{
    public class PlacesRepository : IPlacesRepository
    {
        public int Count()
        {
            throw new NotImplementedException();
        }

        public void Delete(int id)
        {
            throw new NotImplementedException();
        }

        public Place Get(int id)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<Place> GetAll()
        {
            throw new NotImplementedException();
        }

        public void Insert(Place entity)
        {
            throw new NotImplementedException();
        }

        public void Update(Place entity)
        {
            throw new NotImplementedException();
        }
    }
}
