﻿using System;
using System.Collections.Generic;
using System.Text;
using Newtonsoft.Json;

namespace Vendrame.Earthquake.Models
{
    public class JsonEarthquake
    {

    }
}
