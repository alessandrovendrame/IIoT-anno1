﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Vendrame.Earthquake.Models
{
    public class Place:EntityBase<int>
    {
        public string Name { get; set; }
    }
}
