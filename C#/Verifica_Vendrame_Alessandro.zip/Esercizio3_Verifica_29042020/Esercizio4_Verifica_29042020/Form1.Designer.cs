﻿namespace Esercizio4_Verifica_29042020
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtRagioneSociale = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtTelefono = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtIndirizzo = new System.Windows.Forms.TextBox();
            this.txtCitta = new System.Windows.Forms.TextBox();
            this.txtCAP = new System.Windows.Forms.TextBox();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.btnInserisciCliente = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.txtStatoOrdine = new System.Windows.Forms.TextBox();
            this.txtProdotto = new System.Windows.Forms.TextBox();
            this.txtQuantita = new System.Windows.Forms.TextBox();
            this.txtPrezzo = new System.Windows.Forms.TextBox();
            this.btnInsertOrdine = new System.Windows.Forms.Button();
            this.dtDataOrdine = new System.Windows.Forms.DateTimePicker();
            this.dtDataSpedizione = new System.Windows.Forms.DateTimePicker();
            this.txtIDCliente = new System.Windows.Forms.TextBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.GwVisualizzaC = new System.Windows.Forms.DataGridView();
            this.btnVisualizzaClienti = new System.Windows.Forms.Button();
            this.GViewOrdini = new System.Windows.Forms.DataGridView();
            this.btnOrdini = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.GwVisualizzaC)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.GViewOrdini)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnInserisciCliente);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.txtEmail);
            this.groupBox1.Controls.Add(this.txtCAP);
            this.groupBox1.Controls.Add(this.txtCitta);
            this.groupBox1.Controls.Add(this.txtIndirizzo);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.txtTelefono);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.txtRagioneSociale);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(13, 13);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(310, 315);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Inserimento clienti";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(7, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(113, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "Ragione sociale:";
            // 
            // txtRagioneSociale
            // 
            this.txtRagioneSociale.Location = new System.Drawing.Point(126, 19);
            this.txtRagioneSociale.Name = "txtRagioneSociale";
            this.txtRagioneSociale.Size = new System.Drawing.Size(177, 22);
            this.txtRagioneSociale.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(7, 63);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(68, 17);
            this.label2.TabIndex = 2;
            this.label2.Text = "Telefono:";
            // 
            // txtTelefono
            // 
            this.txtTelefono.Location = new System.Drawing.Point(126, 60);
            this.txtTelefono.Name = "txtTelefono";
            this.txtTelefono.Size = new System.Drawing.Size(177, 22);
            this.txtTelefono.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(7, 108);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(64, 17);
            this.label3.TabIndex = 4;
            this.label3.Text = "Indirizzo:";
            // 
            // txtIndirizzo
            // 
            this.txtIndirizzo.Location = new System.Drawing.Point(126, 105);
            this.txtIndirizzo.Name = "txtIndirizzo";
            this.txtIndirizzo.Size = new System.Drawing.Size(177, 22);
            this.txtIndirizzo.TabIndex = 5;
            // 
            // txtCitta
            // 
            this.txtCitta.Location = new System.Drawing.Point(126, 147);
            this.txtCitta.Name = "txtCitta";
            this.txtCitta.Size = new System.Drawing.Size(177, 22);
            this.txtCitta.TabIndex = 6;
            // 
            // txtCAP
            // 
            this.txtCAP.Location = new System.Drawing.Point(126, 190);
            this.txtCAP.Name = "txtCAP";
            this.txtCAP.Size = new System.Drawing.Size(177, 22);
            this.txtCAP.TabIndex = 7;
            // 
            // txtEmail
            // 
            this.txtEmail.Location = new System.Drawing.Point(126, 231);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(177, 22);
            this.txtEmail.TabIndex = 8;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(7, 150);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(40, 17);
            this.label4.TabIndex = 9;
            this.label4.Text = "Città:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(7, 193);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(39, 17);
            this.label5.TabIndex = 10;
            this.label5.Text = "CAP:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(7, 234);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(46, 17);
            this.label6.TabIndex = 11;
            this.label6.Text = "Email:";
            // 
            // btnInserisciCliente
            // 
            this.btnInserisciCliente.Location = new System.Drawing.Point(10, 271);
            this.btnInserisciCliente.Name = "btnInserisciCliente";
            this.btnInserisciCliente.Size = new System.Drawing.Size(293, 29);
            this.btnInserisciCliente.TabIndex = 12;
            this.btnInserisciCliente.Text = "Inserisci cliente";
            this.btnInserisciCliente.UseVisualStyleBackColor = true;
            this.btnInserisciCliente.Click += new System.EventHandler(this.btnInserisciCliente_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.txtIDCliente);
            this.groupBox2.Controls.Add(this.dtDataSpedizione);
            this.groupBox2.Controls.Add(this.dtDataOrdine);
            this.groupBox2.Controls.Add(this.btnInsertOrdine);
            this.groupBox2.Controls.Add(this.txtPrezzo);
            this.groupBox2.Controls.Add(this.txtQuantita);
            this.groupBox2.Controls.Add(this.txtProdotto);
            this.groupBox2.Controls.Add(this.txtStatoOrdine);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Location = new System.Drawing.Point(329, 13);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(321, 352);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Inserimento ordini";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(6, 24);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(55, 17);
            this.label7.TabIndex = 1;
            this.label7.Text = "Cliente:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(6, 63);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(86, 17);
            this.label8.TabIndex = 2;
            this.label8.Text = "Data ordine:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(6, 110);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(114, 17);
            this.label9.TabIndex = 3;
            this.label9.Text = "Data spedizione:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(6, 150);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(89, 17);
            this.label10.TabIndex = 4;
            this.label10.Text = "Stato ordine:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(6, 193);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(66, 17);
            this.label11.TabIndex = 5;
            this.label11.Text = "Prodotto:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(6, 234);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(122, 17);
            this.label12.TabIndex = 6;
            this.label12.Text = "Quantità ordinata:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(6, 271);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(60, 17);
            this.label13.TabIndex = 7;
            this.label13.Text = "Prezzo: ";
            // 
            // txtStatoOrdine
            // 
            this.txtStatoOrdine.Location = new System.Drawing.Point(125, 147);
            this.txtStatoOrdine.Name = "txtStatoOrdine";
            this.txtStatoOrdine.Size = new System.Drawing.Size(177, 22);
            this.txtStatoOrdine.TabIndex = 11;
            // 
            // txtProdotto
            // 
            this.txtProdotto.Location = new System.Drawing.Point(125, 190);
            this.txtProdotto.Name = "txtProdotto";
            this.txtProdotto.Size = new System.Drawing.Size(177, 22);
            this.txtProdotto.TabIndex = 12;
            // 
            // txtQuantita
            // 
            this.txtQuantita.Location = new System.Drawing.Point(125, 231);
            this.txtQuantita.Name = "txtQuantita";
            this.txtQuantita.Size = new System.Drawing.Size(177, 22);
            this.txtQuantita.TabIndex = 13;
            // 
            // txtPrezzo
            // 
            this.txtPrezzo.Location = new System.Drawing.Point(125, 268);
            this.txtPrezzo.Name = "txtPrezzo";
            this.txtPrezzo.Size = new System.Drawing.Size(177, 22);
            this.txtPrezzo.TabIndex = 14;
            // 
            // btnInsertOrdine
            // 
            this.btnInsertOrdine.Location = new System.Drawing.Point(6, 307);
            this.btnInsertOrdine.Name = "btnInsertOrdine";
            this.btnInsertOrdine.Size = new System.Drawing.Size(309, 29);
            this.btnInsertOrdine.TabIndex = 13;
            this.btnInsertOrdine.Text = "Inserisci ordini";
            this.btnInsertOrdine.UseVisualStyleBackColor = true;
            this.btnInsertOrdine.Click += new System.EventHandler(this.btnInsertOrdine_Click);
            // 
            // dtDataOrdine
            // 
            this.dtDataOrdine.Location = new System.Drawing.Point(125, 63);
            this.dtDataOrdine.Name = "dtDataOrdine";
            this.dtDataOrdine.Size = new System.Drawing.Size(177, 22);
            this.dtDataOrdine.TabIndex = 16;
            // 
            // dtDataSpedizione
            // 
            this.dtDataSpedizione.Location = new System.Drawing.Point(125, 105);
            this.dtDataSpedizione.Name = "dtDataSpedizione";
            this.dtDataSpedizione.Size = new System.Drawing.Size(177, 22);
            this.dtDataSpedizione.TabIndex = 17;
            // 
            // txtIDCliente
            // 
            this.txtIDCliente.Location = new System.Drawing.Point(125, 24);
            this.txtIDCliente.Name = "txtIDCliente";
            this.txtIDCliente.Size = new System.Drawing.Size(177, 22);
            this.txtIDCliente.TabIndex = 18;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.btnVisualizzaClienti);
            this.groupBox3.Controls.Add(this.GwVisualizzaC);
            this.groupBox3.Location = new System.Drawing.Point(656, 13);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(392, 352);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Visualizza clienti";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.btnOrdini);
            this.groupBox4.Controls.Add(this.GViewOrdini);
            this.groupBox4.Location = new System.Drawing.Point(1054, 13);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(392, 352);
            this.groupBox4.TabIndex = 3;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Visualizza ordini";
            // 
            // GwVisualizzaC
            // 
            this.GwVisualizzaC.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.GwVisualizzaC.Location = new System.Drawing.Point(6, 24);
            this.GwVisualizzaC.Name = "GwVisualizzaC";
            this.GwVisualizzaC.RowHeadersWidth = 51;
            this.GwVisualizzaC.RowTemplate.Height = 24;
            this.GwVisualizzaC.Size = new System.Drawing.Size(380, 276);
            this.GwVisualizzaC.TabIndex = 0;
            // 
            // btnVisualizzaClienti
            // 
            this.btnVisualizzaClienti.Location = new System.Drawing.Point(6, 317);
            this.btnVisualizzaClienti.Name = "btnVisualizzaClienti";
            this.btnVisualizzaClienti.Size = new System.Drawing.Size(380, 29);
            this.btnVisualizzaClienti.TabIndex = 19;
            this.btnVisualizzaClienti.Text = "Visualizza clienti";
            this.btnVisualizzaClienti.UseVisualStyleBackColor = true;
            this.btnVisualizzaClienti.Click += new System.EventHandler(this.btnVisualizzaClienti_Click);
            // 
            // GViewOrdini
            // 
            this.GViewOrdini.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.GViewOrdini.Location = new System.Drawing.Point(6, 24);
            this.GViewOrdini.Name = "GViewOrdini";
            this.GViewOrdini.RowHeadersWidth = 51;
            this.GViewOrdini.RowTemplate.Height = 24;
            this.GViewOrdini.Size = new System.Drawing.Size(380, 276);
            this.GViewOrdini.TabIndex = 20;
            // 
            // btnOrdini
            // 
            this.btnOrdini.Location = new System.Drawing.Point(6, 317);
            this.btnOrdini.Name = "btnOrdini";
            this.btnOrdini.Size = new System.Drawing.Size(380, 29);
            this.btnOrdini.TabIndex = 21;
            this.btnOrdini.Text = "Visualizza ordini";
            this.btnOrdini.UseVisualStyleBackColor = true;
            this.btnOrdini.Click += new System.EventHandler(this.btnOrdini_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1473, 410);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.Text = "Gestione Ordini";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.GwVisualizzaC)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.GViewOrdini)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnInserisciCliente;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.TextBox txtCAP;
        private System.Windows.Forms.TextBox txtCitta;
        private System.Windows.Forms.TextBox txtIndirizzo;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtTelefono;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtRagioneSociale;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.DateTimePicker dtDataSpedizione;
        private System.Windows.Forms.DateTimePicker dtDataOrdine;
        private System.Windows.Forms.Button btnInsertOrdine;
        private System.Windows.Forms.TextBox txtPrezzo;
        private System.Windows.Forms.TextBox txtQuantita;
        private System.Windows.Forms.TextBox txtProdotto;
        private System.Windows.Forms.TextBox txtStatoOrdine;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtIDCliente;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button btnVisualizzaClienti;
        private System.Windows.Forms.DataGridView GwVisualizzaC;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button btnOrdini;
        private System.Windows.Forms.DataGridView GViewOrdini;
    }
}

