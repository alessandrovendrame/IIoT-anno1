﻿using System;

namespace Vendrame.Northwind.Data
{
    public class Class1
    {
    }
}
