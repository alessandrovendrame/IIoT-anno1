﻿using System;

namespace Vendrame.Northwind.Models
{
    public class Class1
    {
    }
}
