﻿using System;

namespace Maccagnan.Northwind.Services
{
    public class Class1
    {
    }
}
