﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Maccagnan.Northwind.Services
{
    class ProductService
    {
    }
}
